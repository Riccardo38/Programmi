
#include <iostream>
using namespace std;
int main()
{
float soldi, prezzo;
cout<<"inserisci prezzo oggetto";
cin>>prezzo;
cout<<"inserisci soldi disponibili";
cin>>soldi;
if(soldi>prezzo){
    cout<<"Puoi comprarlo e ti rimangono ben "<<soldi-prezzo<<" euro!";
}
else{
    cout<<"Non puoi comprarlo ti mancano dei soldi";
}
}