#include <iostream>
using namespace std;
    int main() {
    int totale=0, n1=0;
    while(totale<=30){
        cout<<"inserisci un numero";
        cin>>n1;
        totale=totale+n1;
    }
    cout<<"la somma dei numeri e maggiore di 30 :( ";
}