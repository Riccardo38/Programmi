
#include <iostream>
using namespace std;
int main()
{
int n;
cout<<"Inserisci un numero";
cin>>n;
cout<<"Il precedente di "<<n<<" e "<<n-1<<" il successivo invece e "<<n+1;
}