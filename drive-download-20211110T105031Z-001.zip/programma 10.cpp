#include <iostream>
using namespace std;
    int main() {
    int totale=0, n1=0;
    while(n1!=99){
        cout<<"inserisci un numero";
        cin>>n1;
        totale=totale+n1;
    }
    cout<<"hai inserito 99 ";
}