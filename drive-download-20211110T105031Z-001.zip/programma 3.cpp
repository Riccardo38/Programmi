
#include <iostream>
using namespace std;
int main()
{
int b, h, a;
cout<<"inserisci la base";
cin>>b;
cout<<"inserisci altezza";
cin>>h;
a=b*h;
cout<<"l'area del rettangolo e di "<<a;
}