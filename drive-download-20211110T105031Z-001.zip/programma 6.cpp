#include <iostream>
using namespace std;
int main() {
    int giorni, totale, sconto;
    cout<<"inserisci per quanti giorni noleggerai l'auto";
    cin>>giorni;
    totale=30*giorni;
    sconto=totale*10/100;
    if(giorni>6){
        cout<<"In totale compreso lo sconto pagherai "<<totale-sconto<<" euro";
    }
    else{
        cout<<"in totale pagherai "<<totale<<" euro";
    }
}