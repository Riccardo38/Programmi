
#include <iostream>
using namespace std;
int main()
{
int a, b, c;
cout<<"Inserisci un numero";
cin>>a;
cout<<"inserisci un altro numero";
cin>>b;
c=a*b;
cout<<"La moltiplicazione tra i due numeri e di "<<c;
}
