#include <iostream>
using namespace std;
int main() {
    float temperatura;
    cout<<"inserisci temperatura";
    cin>>temperatura;
    if(temperatura>0){
        cout<<"la temperatura e maggiore di 0";
    }
    if(temperatura==0){
        cout<<"la temperatura e 0";
    }
    if(temperatura<0){
        cout<<"la temperatura e minore di 0";
    }
}