
#include <iostream>
using namespace std;
int main()
{
float prezzo, peso, totale;
cout<<"inserisci il costo per kg";
cin>>prezzo;
cout<<"quanti kg acquisterai?";
cin>>peso;
totale=prezzo*peso;
cout<<"tutto viene a costarti "<<totale<<" euro";
}