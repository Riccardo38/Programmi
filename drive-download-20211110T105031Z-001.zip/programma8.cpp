#include <iostream>
using namespace std;
int main() {
    int n1, n2, n3;
    cout<<"inserisci il primo numero";
    cin>>n1;
    cout<<"inserisci il secondo numero";
    cin>>n2;
    cout<<"inserisci il terzo numero";
    cin>>n3;
    if(n1>n2 and n1>n2){
        cout<<"Il maggiore tra i tre e "<<n1;
    }
    if(n2>n1 and n2>n3){
        cout<<"Il maggiore tra i tre e "<<n2;
    }
    if(n3>n1 and n3>n2){
        cout<<"Il maggiore tra i tre e "<<n2;
    }
}