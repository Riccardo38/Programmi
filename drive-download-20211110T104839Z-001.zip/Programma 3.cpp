/*Verificare se un numero dato in input è divisibile sia per 3 sia per 5. */

#include <iostream>
using namespace std;
int main(){
    int n1;
    cout<<"Inserisci un numero ";
    cin>>n1;
    if(n1 % 3==0 and n1% 5==0){
        cout<<"Il numero è divisibile sia per 3 che per 5"; 
    }
    else{
        cout<<"Il numero non è divisibile ne per 3 che per 5";
    }
}