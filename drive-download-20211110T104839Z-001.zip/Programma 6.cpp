/*Determinare se un numero A ha la stessa parità di un numero B.
(Due numeri hanno la  stessa parità se sono entrambi pari o entrambi dispari). */

#include <iostream>
using namespace std;
int main(){
    int n1, n2;
    cout<<"Inserisci due numeri "<<endl;
    cin>>n1;
    cin>>n2;
    if(n1%2==0 and n2%2==0){
        cout<<"Entrambi i numeri sono pari ";
    }
    else{
        cout<<"Entrambi i numeri sono dispari ";
    }
}
