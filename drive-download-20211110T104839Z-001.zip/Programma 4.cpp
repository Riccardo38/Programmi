/*Verificare se un numero dato in input è divisibile per 3 o per 7. */

#include <iostream>
using namespace std;
int main(){
    int n1;
    cout<<"Inserisci un numero ";
    cin>>n1;
    if(n1 % 3==0 or n1% 7==0){
        cout<<"Il numero è divisibile o per 3 o per 7"; 
    }
    else{
        cout<<"Il numero non è divisibile ne per 3 che per 7";
    }
}