/*Dato un numero intero N, stabilire se è pari o dispari.*/

#include <iostream>
using namespace std;
int main(){
    int n;
    cout<<"Inserisci un numero ";
    cin>>n;
    if(n % 2==0){
        cout<<"il numero è pari ";
    }
    else{
        cout<<"il numero è dispari ";
    }
}
