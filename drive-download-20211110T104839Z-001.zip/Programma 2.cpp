/*Dato un numero intero N, stabilire se è divisibile per A. (Controllare il resto della 
divisione).*/

#include <iostream>
using namespace std;
int main(){
    int n1, n2;
    cout<<"Inserisci un numero ";
    cin>>n1;
    cout<<"inserisci un'altro numero ";
    cin>>n2;
    if(n1 % n2==0 or n2 % n1==0){
        cout<<"Un numero tra i due è un divisore dell' altro ";
    }
    else{
        cout<<"Nessuno è divisore di nessuno ";
    }
}
