/* Dati due numeri interi, stabilire, senza effettuare il calcolo,
se la loro somma è pari o dispari. */

#include <iostream>
using namespace std;
int main(){
    int n1, n2;
    cout<<"Inserisci 2 numeri"<<endl;
    cin>>n1;
    cin>>n2;
    if((n1+n2)%2==0){
        cout<<"La somma tra i due è pari";
    }
    else{
        cout<<"La somma tra i due è dispari";
    }
}