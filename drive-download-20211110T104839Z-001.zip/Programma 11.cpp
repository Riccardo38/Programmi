/* Data la base e l'esponente intero di una potenza,
stabilire senza effettuare il calcolo, il segno di tale potenza. */

#include <iostream>
using namespace std;
int main(){
    int base, esponente;
    cout<<"Inserisci base "<<endl;
    cin>>base;
    cout<<"inserisci esponente "<<endl;
    cin>>esponente;
    if(base>0 and esponente>0){
        cout<<"Il tutto è positivo ";
    }
    else{
        cout<<"il tutto è negativo";
    }
}