/*Dato il numeratore e il denominatore di una frazione,
stabilire se tale frazione è propria, impropria o apparente.  */

#include <iostream>
using namespace std;
int main(){
    int numeratore, denominatore;
    cout<<"Inserisci la frazione "<<endl;
    cin>>numeratore;
    cout<<"-"<<endl;
    cin>>denominatore;
    if(numeratore<denominatore){
        cout<<"La frazione è propria ";
    }
    if(numeratore>denominatore){
        cout<<"La frazione è impropria ";
    }
    if(numeratore==denominatore){
        cout<<"La frazione è apparente ";
    }
}
    