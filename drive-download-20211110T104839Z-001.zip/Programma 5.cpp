/*Verificare se un numero dato in input è divisibile per 3 ma non per 5.*/

#include <iostream>
using namespace std;
int main(){
    int n1;
    cout<<"Inserisci un numero ";
    cin>>n1;
    if(n1 % 3==0 and n1 % 5!=0){
        cout<<"Il numero è divisibile per 3 ma non per 5"; 
    }
    if(n1 % 3!=0){
        cout<<"Il numero non è divisibile neanche per 3";
    }
}