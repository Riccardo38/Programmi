/*Stabilire se un numero naturale N, diverso da zero, è divisore di altri due numeri qualsiasi. */

#include <iostream>
using namespace std;
int main(){
    int n1, n2, n3;
    cout<<"Inserisci un numero diverso da zero ";
    cin>>n1;
    cout<<"ora inserisci 2 numeri a caso"<<endl;
    cin>>n2;
    cin>>n3;
    if(n1%n2==0 and n1%n3==0){
        cout<<"Il numero "<<n1<<" è un divisore degli altri 2";
    }
    else{
        cout<<"Il numero "<<n1<<" non è divisore di entrambi";
    }
}
