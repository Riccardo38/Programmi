/* Stampare i numeri pari minori di N.*/

#include <iostream>
using namespace std;
int main(){
    int n=0, inc;
    cout<<"Inserisci un numero ";
    cin>>inc;
    while(n>=0 and n<=inc ){
        cout<<n<<endl;
        n=n+2;
    }
}