/* Stampare i numeri pari minori di N in ordine decrescente.*/

#include <iostream>
using namespace std;
int main(){
    int inc;
    cout<<"Inserisci un numero ";
    cin>>inc;
    int n=inc;
    while(n>=0 and n<=inc ){
        cout<<n<<endl;
        n=n-2;
    }
}