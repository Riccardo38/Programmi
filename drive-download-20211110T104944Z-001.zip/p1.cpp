/* Stampare i primi N numeri interi.*/

#include <iostream>
using namespace std;
int main(){
    int n=1, inc;
    cout<<"Inserisci un numero ";
    cin>>inc;
    while(n>0 and n<=inc ){
        cout<<n<<endl;
        n++;
    }
}